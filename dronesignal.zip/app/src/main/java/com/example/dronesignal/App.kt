package com.example.dronesignal

import android.Manifest
import android.app.*
import android.content.*
import android.media.*
import android.os.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.composed
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import kotlinx.coroutines.*
import java.net.*
import java.text.SimpleDateFormat
import java.time.OffsetDateTime
import java.util.*
import java.util.concurrent.TimeUnit

private val YandexRed = Color(0xFFFC3F1D)
private val YandexRedSoft = Color(0xFFFFE9E4)
private val BgColor = Color(0xFFF5F5F7)
private val CardColor = Color.White
private val TextPrimary = Color(0xFF1A1A1A)
private val TextSecondary = Color(0xFF8C8C8C)
private val DividerColor = Color(0xFFEDEDED)
private val GreenColor = Color(0xFF22A65A)
private val GreenSoft = Color(0xFFE7F6EE)
private val NeutralSoft = Color(0xFFF4F4F5)

data class Station(val region: String, val freqMhz: Double, val streamUrl: String? = null, val backupUrl: String? = null) {
    val label get() = "$region — ${freqMhz.toString().replace('.', ',')} FM"
    val hasStream get() = !streamUrl.isNullOrBlank()
}
object Stations {
    private const val DR_MAIN = "http://dorognoe.hostingradio.ru:8000/dorognoe"
    private const val DR_BACKUP = ""
    val all = listOf(
        Station("Весёло-Вознесенка",90.4,DR_MAIN,DR_BACKUP), Station("Новоазовск",90.4,DR_MAIN,DR_BACKUP),
        Station("Мариуполь",94.3,DR_MAIN,DR_BACKUP), Station("Бердянск",95.5,DR_MAIN,DR_BACKUP),
        Station("Инзовка",95.5,DR_MAIN,DR_BACKUP), Station("Мелитополь",95.1,DR_MAIN,DR_BACKUP),
        Station("Новогригорьевка",95.5,DR_MAIN,DR_BACKUP), Station("Геническ",95.1,DR_MAIN,DR_BACKUP),
        Station("Чонгар",95.1,DR_MAIN,DR_BACKUP), Station("Новотроицкое",95.1,DR_MAIN,DR_BACKUP),
        Station("Новотроицкое / Чаплинка",95.1,DR_MAIN,DR_BACKUP),
        Station("Чаплинка / Каланчак / АПП Армянск",95.1,DR_MAIN,DR_BACKUP)
    )
}
object AlertState {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("alert_state",Context.MODE_PRIVATE)
    fun isActive(c: Context) = p(c).getBoolean("active",false)
    fun since(c: Context) = p(c).getLong("since",0L)
    fun source(c: Context) = p(c).getString("source","—") ?: "—"
    fun lastAlarm(c: Context) = p(c).getLong("last_alarm",0L)
    fun expireMinutes(c: Context) = p(c).getInt("expire_min",60)
    fun setExpireMinutes(c: Context,min: Int) { p(c).edit().putInt("expire_min",min.coerceIn(10,180)).apply() }
    fun start(c: Context,source: String) {
        val now=System.currentTimeMillis()
        p(c).edit().putBoolean("active",true).putLong("since",now).putLong("last_alarm",now).putString("source",source).apply()
    }
    fun renew(c: Context,source: String) { p(c).edit().putLong("last_alarm",System.currentTimeMillis()).putString("source",source).apply() }
    fun stop(c: Context,source: String) { p(c).edit().putBoolean("active",false).putString("source",source).apply() }
}
enum class PostKind { ALARM,CLEAR,IGNORE }
data class Classified(val kind: PostKind,val massive: Boolean,val region: String,val voiceText: String) {
    val relevant get() = region=="ДНР" || region=="ЛНР"
}
object AlarmClassifier {
    private fun norm(s: String) = s.lowercase(Locale("ru","RU")).replace('ё','е')
    private val alarmMarkers=listOf("бпла","беспилот","тревога","ракетная опасность","авиационная ракетная")
    private val massiveMarkers=listOf("массово","массовая атака","массированн")
    fun classify(raw: String): Classified {
        val clean=raw.replace(Regex("https?://\\S+"),"").replace(Regex("\\s+")," ").trim()
        val t=norm(clean)
        val kind=when {
            listOf("отбой","отмена тревоги","опасность отменена","все чисто").any { it in t } -> PostKind.CLEAR
            "по штормам" in t && "ранее объявленные регионы" in t -> PostKind.CLEAR
            alarmMarkers.any { it in t } -> PostKind.ALARM
            else -> PostKind.IGNORE
        }
        val massive=massiveMarkers.any { it in t }
        val region=when { "днр" in t -> "ДНР"; "лнр" in t -> "ЛНР"; else -> "" }
        val voice=when {
            kind==PostKind.CLEAR -> "Отбой опасности. "+clean.take(160)
            massive -> "Внимание! Массовая атака беспилотников. "+clean.take(160)
            else -> "Внимание! Опасность беспилотников. "+clean.take(160)
        }
        return Classified(kind,massive,region,voice)
    }
}
data class AlarmPost(val id: Long,val timeMs: Long,val text: String)
object TelegramAlarmSource {
    const val CHANNEL="lpr1_LDPR_alarm"
    fun fetchAll(): List<AlarmPost>? {
        val html=download("https://t.me/s/$CHANNEL") ?: return null
        return html.split("tgme_widget_message_wrap").drop(1).mapNotNull { parsePost(it) }.sortedBy { it.id }
    }
    internal fun parsePost(block: String): AlarmPost? {
        val id=Regex("data-post=\"[^\"]*?/(\\d+)\"").find(block)?.groupValues?.get(1)?.toLongOrNull() ?: return null
        val raw=Regex("tgme_widget_message_text[^>]*>(.*?)</div>",RegexOption.DOT_MATCHES_ALL).find(block)?.groupValues?.get(1) ?: ""
        val text=raw.replace(Regex("<br\\s*/?>"),"\n").replace(Regex("<[^>]+>")," ")
            .replace("&quot;","\"").replace("&#39;","'").replace("&amp;","&")
            .replace("&lt;","<").replace("&gt;",">").replace(Regex("\\s+")," ").trim()
        val time=Regex("datetime=\"([^\"]+)\"").find(block)?.groupValues?.get(1)
            ?.let { runCatching { OffsetDateTime.parse(it).toInstant().toEpochMilli() }.getOrNull() } ?: 0L
        return AlarmPost(id,time,text)
    }
    internal fun download(url: String): String? = runCatching {
        val conn=(URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout=10000;readTimeout=10000
            setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        }
        try { if(conn.responseCode !in 200..299) null else conn.inputStream.bufferedReader().use { it.readText() } }
        finally { conn.disconnect() }
    }.getOrNull()
}
object AlarmGuard {
    private const val MAX_POST_AGE_MS=10*60_000L
    fun poll(ctx: Context) {
        val now=System.currentTimeMillis()
        val posts=TelegramAlarmSource.fetchAll()
        if(posts==null) { expireIfSilent(ctx,now);return }
        val prefs=ctx.applicationContext.getSharedPreferences("guard",Context.MODE_PRIVATE)
        val lastId=prefs.getLong("last_id",0L)
        val fresh=posts.filter { it.id>lastId }
        if(fresh.isEmpty()) { expireIfSilent(ctx,now);return }
        var maxSeen=lastId
        for(post in fresh) {
            maxSeen=maxOf(maxSeen,post.id)
            if(post.timeMs<=0 || post.timeMs>now+60_000L || now-post.timeMs>MAX_POST_AGE_MS) continue
            handle(ctx,post.id,AlarmClassifier.classify(post.text))
        }
        prefs.edit().putLong("last_id",maxSeen).apply()
        expireIfSilent(ctx,now)
    }
    private fun handle(ctx: Context,id: Long,c: Classified) {
        val active=AlertState.isActive(ctx)
        when(c.kind) {
            PostKind.ALARM -> {
                if(!c.relevant && !active) return
                if(!active) { AlertState.start(ctx,"tg:$id");RadioService.start(ctx,c.voiceText) }
                else { AlertState.renew(ctx,"tg:$id");RadioService.update(ctx,c.voiceText) }
            }
            PostKind.CLEAR -> if(active && c.relevant) { AlertState.stop(ctx,"отбой tg:$id");RadioService.stop(ctx) }
            PostKind.IGNORE -> Unit
        }
    }
    private fun expireIfSilent(ctx: Context,now: Long) {
        if(!AlertState.isActive(ctx)) return
        val last=AlertState.lastAlarm(ctx)
        if(last>0 && now-last>AlertState.expireMinutes(ctx)*60_000L) {
            AlertState.stop(ctx,"таймаут");RadioService.stop(ctx)
        }
    }
}
class StreamPlayer(private val context: Context, private val onState: (Boolean)->Unit) {
    private var player: MediaPlayer?=null
    private val h=Handler(Looper.getMainLooper())
    private var lastPos=0
    private var stallChecks=0
    private var retries=0
    fun play(url: String,backup: String?=null) { stopInternal();retries=0;open(url,backup) }
    private fun open(url: String,backup: String?) {
        val mp=MediaPlayer()
        mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
        player=mp
        val headers=hashMapOf("User-Agent" to "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
            "Referer" to "https://top-radio.ru/","Icy-MetaData" to "0")
        try {
            mp.setDataSource(context, android.net.Uri.parse(url), headers)
            mp.setOnPreparedListener { it.start();onState(true);watchStall(url,backup) }
            mp.setOnErrorListener { _,_,_ -> onState(false);fallback(url,backup);true }
            mp.setOnCompletionListener { fallback(url,backup) }
            mp.prepareAsync()
        } catch(e: Exception) { onState(false);fallback(url,backup) }
    }
    private fun fallback(url: String,backup: String?) {
        h.postDelayed({
            stopInternal()
            when {
                retries<1 -> { retries++;open(url,backup) }
                !backup.isNullOrBlank() && url!=backup -> { retries=0;open(backup,null) }
                else -> onState(false)
            }
        },2000)
    }
    private fun watchStall(url: String,backup: String?) {
        h.removeCallbacksAndMessages(null)
        h.postDelayed(object: Runnable {
            override fun run() {
                val mp=player ?: return
                val pos=runCatching { mp.currentPosition }.getOrDefault(-1)
                if(pos==lastPos) {
                    if(++stallChecks>=3) { fallback(url,backup);return }
                } else { stallChecks=0;lastPos=pos }
                h.postDelayed(this,2000)
            }
        },3000)
    }
    fun stop() { stopInternal();onState(false) }
    private fun stopInternal() {
        h.removeCallbacksAndMessages(null)
        runCatching { player?.stop() };player?.release();player=null;lastPos=0;stallChecks=0
    }
}
class RadioService: Service() {
    private var tts: TextToSpeech?=null
    private var ttsReady=false
    private var alertText=""
    private var index=0
    private var streamLive=false
    private val handler=Handler(Looper.getMainLooper())
    private lateinit var vibrator: Vibrator
    private val stations=Stations.all
    private val stream=StreamPlayer(this) { alive ->
        streamLive=alive
        if(!alive && AlertState.isActive(this)) speakAlert()
        updateNotif(notifLine())
    }
    private val scanTicker=object: Runnable {
        override fun run() {
            if(!AlertState.isActive(this@RadioService)) { stopClean();return }
            playStation(stations[index])
            handler.postDelayed({ index=(index+1)%stations.size;handler.post(this) },20_000L)
        }
    }
    private val voiceTicker=object: Runnable {
        override fun run() { speakAlert();handler.postDelayed(this,30_000L) }
    }
    override fun onCreate() {
        super.onCreate()
        vibrator=getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        tts=TextToSpeech(this) { status ->
            if(status==TextToSpeech.SUCCESS) {
                tts?.language=Locale("ru","RU");tts?.setSpeechRate(0.95f);ttsReady=true
                if(AlertState.isActive(this)) speakAlert()
            }
        }
        startForeground(1,buildNotif("Опасность БПЛА"))
    }
    override fun onStartCommand(intent: Intent?,flags: Int,startId: Int): Int {
        when(intent?.action) {
            ACTION_START -> {
                alertText=intent.getStringExtra(EXTRA_TEXT).orEmpty();index=0
                vibrateDanger();speakAlert()
                handler.removeCallbacks(scanTicker);handler.post(scanTicker)
                handler.removeCallbacks(voiceTicker);handler.postDelayed(voiceTicker,30_000L)
            }
            ACTION_UPDATE -> { alertText=intent.getStringExtra(EXTRA_TEXT).orEmpty();speakAlert() }
            ACTION_STOP -> { stopClean();return START_NOT_STICKY }
        }
        return START_STICKY
    }
    private fun playStation(st: Station) {
        if(st.hasStream && !streamLive) stream.play(st.streamUrl!!,st.backupUrl)
        else if(!st.hasStream) stream.stop()
        vibrateDanger();updateNotif(notifLine())
    }
    private fun notifLine()="${index+1}/${stations.size} · ${stations[index].label} · "+if(streamLive) "эфир" else "голос"
    private fun speakAlert() {
        if(!ttsReady || streamLive) return
        val st=stations[index]
        val text=alertText.ifBlank { "Внимание! Опасность беспилотников. Настройте приёмник на ${st.freqMhz.toString().replace('.', ',')} FM, ${st.region}." }
        tts?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"v${System.nanoTime()}")
    }
    private fun vibrateDanger() {
        vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0,400,200,400,200,800),-1))
    }
    private fun stopClean() {
        handler.removeCallbacksAndMessages(null);stream.stop();tts?.stop()
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()
    }
    private fun buildNotif(text: String): Notification {
        val ch="drone_alert"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel(ch,"Опасность БПЛА",NotificationManager.IMPORTANCE_HIGH))
        val stopPi=PendingIntent.getService(this,0,Intent(this,RadioService::class.java).setAction(ACTION_STOP),PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this,ch).setContentTitle("⚠ Опасность БПЛА").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_alert).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true).addAction(0,"Отключить",stopPi).build()
    }
    private fun updateNotif(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1,buildNotif(text))
    }
    override fun onBind(intent: Intent?): IBinder?=null
    override fun onDestroy() { stream.stop();tts?.shutdown();handler.removeCallbacksAndMessages(null);super.onDestroy() }
    companion object {
        const val ACTION_START="START";const val ACTION_UPDATE="UPDATE";const val ACTION_STOP="STOP";const val EXTRA_TEXT="text"
        fun start(ctx: Context,text: String="") {
            ContextCompat.startForegroundService(ctx,Intent(ctx,RadioService::class.java).setAction(ACTION_START).putExtra(EXTRA_TEXT,text))
        }
        fun update(ctx: Context,text: String) {
            runCatching { ctx.startService(Intent(ctx,RadioService::class.java).setAction(ACTION_UPDATE).putExtra(EXTRA_TEXT,text)) }
        }
        fun stop(ctx: Context) { runCatching { ctx.startService(Intent(ctx,RadioService::class.java).setAction(ACTION_STOP)) } }
    }
}
class FastPollService: Service() {
    private val scope=CoroutineScope(Dispatchers.IO+SupervisorJob())
    override fun onCreate() {
        super.onCreate()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel("poll","Слежение",NotificationManager.IMPORTANCE_MIN))
        startForeground(2,NotificationCompat.Builder(this,"poll").setContentTitle("Слежение за каналом тревог")
            .setContentText("Ожидание сигнала…").setSmallIcon(android.R.drawable.ic_menu_compass)
            .setPriority(NotificationCompat.PRIORITY_MIN).setOngoing(true).build())
        scope.launch { while(isActive) { runCatching { AlarmGuard.poll(this@FastPollService) };delay(20_000L) } }
    }
    override fun onStartCommand(intent: Intent?,flags: Int,startId: Int)=START_STICKY
    override fun onBind(intent: Intent?): IBinder?=null
    override fun onDestroy() { scope.cancel();super.onDestroy() }
    companion object {
        fun start(ctx: Context) { ContextCompat.startForegroundService(ctx,Intent(ctx,FastPollService::class.java)) }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx,FastPollService::class.java)) }
    }
}
class AlertCheckWorker(ctx: Context,params: WorkerParameters): CoroutineWorker(ctx,params) {
    override suspend fun doWork(): Result {
        withContext(Dispatchers.IO) { runCatching { AlarmGuard.poll(applicationContext) } }
        return Result.success()
    }
    companion object {
        fun schedule(ctx: Context) {
            val req=PeriodicWorkRequestBuilder<AlertCheckWorker>(15,TimeUnit.MINUTES)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("alert_check",ExistingPeriodicWorkPolicy.KEEP,req)
        }
    }
}
object HistoryProbe {
    fun analyze(pages: Int=10): String {
        val all=mutableListOf<AlarmPost>()
        all+=TelegramAlarmSource.fetchAll().orEmpty()
        var before=all.minOfOrNull { it.id } ?: return "Нет постов канала"
        repeat(pages-1) {
            val page=TelegramAlarmSource.download("https://t.me/s/${TelegramAlarmSource.CHANNEL}?before=$before")
                ?.split("tgme_widget_message_wrap")?.drop(1)?.mapNotNull { TelegramAlarmSource.parsePost(it) } ?: return@repeat
            if(page.isEmpty()) return@repeat
            all+=page;before=page.minOf { it.id };Thread.sleep(1500)
        }
        val sorted=all.distinctBy { it.id }.sortedBy { it.id }
        if(sorted.size<4) return "Мало данных: ${sorted.size} постов"
        val durations=mutableListOf<Long>()
        var start: Long?=null
        for(p in sorted) {
            when(AlarmClassifier.classify(p.text).kind) {
                PostKind.ALARM -> if(start==null) start=p.timeMs
                PostKind.CLEAR -> { start?.let { if(p.timeMs>it) durations+=p.timeMs-it };start=null }
                PostKind.IGNORE -> Unit
            }
        }
        if(durations.isEmpty()) return "Эпизодов с отбоем нет (постов: ${sorted.size})"
        val s=durations.sorted()
        return buildString {
            appendLine("Постов: ${sorted.size}")
            appendLine("Эпизодов с отбоем: ${durations.size}")
            appendLine("Средняя: ${durations.average().toLong()/60_000} мин")
            appendLine("Медиана: ${s[s.size/2]/60_000} мин")
            appendLine("P90: ${s[(s.size*0.9).toInt().coerceAtMost(s.lastIndex)]/60_000} мин")
        }
    }
}
@Composable
fun YCard(modifier: Modifier=Modifier,content: @Composable ColumnScope.()->Unit) {
    Column(modifier.fillMaxWidth().shadow(4.dp,RoundedCornerShape(24.dp),spotColor=Color(0x14000000))
        .clip(RoundedCornerShape(24.dp)).background(CardColor).padding(20.dp),content=content)
}
@Composable
fun PulseDot(active: Boolean,color: Color) {
    if(!active) { Box(Modifier.size(10.dp).clip(CircleShape).background(color));return }
    val transition=rememberInfiniteTransition(label="pulse")
    val alpha by transition.animateFloat(initialValue=0.35f,targetValue=1f,
        animationSpec=infiniteRepeatable(tween(900,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="alpha")
    Box(Modifier.size(10.dp).clip(CircleShape).background(color.copy(alpha=alpha)))
}
@Composable
fun StatusHero(active: Boolean,title: String,subtitle: String) {
    val bg=if(active) YandexRed else GreenSoft
    val fg=if(active) Color.White else TextPrimary
    val sub=if(active) Color(0xFFFFD6CC) else TextSecondary
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
        .background(Brush.linearGradient(listOf(bg,if(active) Color(0xFFE8391A) else bg))).padding(24.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            PulseDot(active,if(active) Color.White else GreenColor);Spacer(Modifier.width(10.dp))
            Text(if(active) "ОПАСНОСТЬ" else "СЛЕЖЕНИЕ",fontSize=11.sp,fontWeight=FontWeight.Bold,
                letterSpacing=1.4.sp,color=if(active) Color(0xFFFFD6CC) else TextSecondary)
        }
        Spacer(Modifier.height(12.dp))
        Text(title,fontSize=26.sp,fontWeight=FontWeight.Bold,color=fg)
        Spacer(Modifier.height(6.dp));Text(subtitle,fontSize=14.sp,color=sub)
    }
}
@Composable
fun YPrimary(text: String,onClick: ()->Unit,modifier: Modifier=Modifier) {
    Button(onClick=onClick,modifier=modifier.height(52.dp),shape=RoundedCornerShape(14.dp),
        colors=ButtonDefaults.buttonColors(containerColor=TextPrimary,contentColor=Color.White),
        elevation=ButtonDefaults.buttonElevation(0.dp,0.dp,0.dp)) {
        Text(text,fontWeight=FontWeight.SemiBold,fontSize=15.sp)
    }
}
@Composable
fun YSecondary(text: String,onClick: ()->Unit,modifier: Modifier=Modifier) {
    Button(onClick=onClick,modifier=modifier.height(52.dp),shape=RoundedCornerShape(14.dp),
        colors=ButtonDefaults.buttonColors(containerColor=NeutralSoft,contentColor=TextPrimary),
        elevation=ButtonDefaults.buttonElevation(0.dp,0.dp,0.dp)) {
        Text(text,fontWeight=FontWeight.SemiBold,fontSize=15.sp)
    }
}
@Composable
fun YDanger(text: String,onClick: ()->Unit,modifier: Modifier=Modifier) {
    Button(onClick=onClick,modifier=modifier.height(52.dp),shape=RoundedCornerShape(14.dp),
        colors=ButtonDefaults.buttonColors(containerColor=YandexRed,contentColor=Color.White),
        elevation=ButtonDefaults.buttonElevation(0.dp,0.dp,0.dp)) {
        Text(text,fontWeight=FontWeight.SemiBold,fontSize=15.sp)
    }
}
fun Modifier.clickableNoRipple(onClick: ()->Unit): Modifier=composed {
    clickable(interactionSource=remember { MutableInteractionSource() },indication=null,onClick=onClick)
}
class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),1)
        AlertCheckWorker.schedule(this)
        setContent {
            MaterialTheme(colorScheme=lightColorScheme(primary=YandexRed,background=BgColor,surface=CardColor)) { AppScreen() }
        }
    }
}
@Composable
fun AppScreen() {
    val ctx=LocalContext.current
    val scope=rememberCoroutineScope()
    var active by remember { mutableStateOf(AlertState.isActive(ctx)) }
    var since by remember { mutableStateOf(AlertState.since(ctx)) }
    var source by remember { mutableStateOf(AlertState.source(ctx)) }
    var expire by remember { mutableStateOf(AlertState.expireMinutes(ctx)) }
    var lastPost by remember { mutableStateOf("—") }
    var lastKind by remember { mutableStateOf("—") }
    var lastTime by remember { mutableStateOf("") }
    var netError by remember { mutableStateOf(false) }
    var probe by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while(true) {
            active=AlertState.isActive(ctx);since=AlertState.since(ctx);source=AlertState.source(ctx)
            val posts=withContext(Dispatchers.IO) { TelegramAlarmSource.fetchAll() }
            if(posts==null) netError=true
            else {
                netError=false
                posts.maxByOrNull { it.id }?.let {
                    lastPost=it.text.take(160)
                    lastTime=if(it.timeMs>0) SimpleDateFormat("HH:mm",Locale("ru")).format(Date(it.timeMs)) else ""
                    lastKind=when(AlarmClassifier.classify(it.text).kind) {
                        PostKind.ALARM -> "Тревога";PostKind.CLEAR -> "Отбой";PostKind.IGNORE -> "Обычный пост"
                    }
                }
            }
            delay(15_000)
        }
    }
    Surface(Modifier.fillMaxSize(),color=BgColor) {
        LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),
            verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item {
                Column(Modifier.padding(horizontal=4.dp,vertical=8.dp)) {
                    Text("ДНР Сигнал",fontSize=20.sp,fontWeight=FontWeight.Bold,color=TextPrimary)
                    Text("Оповещение об опасности БПЛА",fontSize=13.sp,color=TextSecondary)
                }
            }
            item {
                val mins=((System.currentTimeMillis()-since)/60_000).coerceAtLeast(0)
                StatusHero(active,if(active) "Опасность БПЛА" else "Всё спокойно",
                    if(active) "$mins мин · источник $source" else "Приложение ждёт сигнал тревоги")
            }
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    if(active) YDanger("Заглушить",{
                        AlertState.stop(ctx,"вручную");RadioService.stop(ctx)
                    },Modifier.weight(1f))
                    else YPrimary("Включить слежение",{
                        FastPollService.start(ctx);AlertCheckWorker.schedule(ctx)
                    },Modifier.weight(1f))
                    YSecondary(if(active) "Сброс" else "Тест",{
                        if(active) { AlertState.stop(ctx,"вручную");RadioService.stop(ctx) }
                        else { AlertState.start(ctx,"вручную");RadioService.start(ctx) }
                    },Modifier.weight(1f))
                }
            }
            item {
                YCard {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(YandexRedSoft),
                            contentAlignment=Alignment.Center) {
                            Icon(Icons.Filled.VolumeUp,contentDescription=null,tint=YandexRed)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Дорожное радио",fontWeight=FontWeight.SemiBold)
                            Text("Эфир при тревоге · 90,4–95,5 FM",fontSize=13.sp,color=TextSecondary)
                        }
                        Box(Modifier.clip(RoundedCornerShape(8.dp))
                            .background(if(Stations.all.first().hasStream) GreenSoft else NeutralSoft)
                            .padding(horizontal=8.dp,vertical=4.dp)) {
                            Text(if(Stations.all.first().hasStream) "поток задан" else "нет потока",
                                fontSize=11.sp,fontWeight=FontWeight.Medium,
                                color=if(Stations.all.first().hasStream) GreenColor else TextSecondary)
                        }
                    }
                }
            }
            item {
                YCard {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text("Канал тревог",fontWeight=FontWeight.SemiBold)
                        Text("t.me/"+TelegramAlarmSource.CHANNEL,fontSize=12.sp,color=TextSecondary)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        val tagPair=when(lastKind) {
                            "Тревога" -> YandexRed to YandexRedSoft
                            "Отбой" -> GreenColor to GreenSoft
                            else -> TextSecondary to NeutralSoft
                        }
                        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(tagPair.second)
                            .padding(horizontal=10.dp,vertical=5.dp)) {
                            Text(lastKind,fontSize=12.sp,fontWeight=FontWeight.SemiBold,color=tagPair.first)
                        }
                        Spacer(Modifier.width(8.dp))
                        if(lastTime.isNotBlank()) Text(lastTime,fontSize=12.sp,color=TextSecondary)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(lastPost,fontSize=14.sp,color=TextPrimary)
                    if(netError) {
                        Spacer(Modifier.height(8.dp))
                        Text("Канал недоступен · повтор при следующем опросе",fontSize=12.sp,color=YandexRed)
                    }
                }
            }
            item {
                YCard {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,
                        verticalAlignment=Alignment.CenterVertically) {
                        Text("Настройки",fontWeight=FontWeight.SemiBold)
                        Text(if(showSettings) "Свернуть" else "Развернуть",fontSize=13.sp,color=YandexRed,
                            modifier=Modifier.clickableNoRipple { showSettings=!showSettings })
                    }
                    AnimatedVisibility(visible=showSettings) {
                        Column {
                            Spacer(Modifier.height(8.dp))
                            Box(Modifier.fillMaxWidth().height(1.dp).background(DividerColor))
                            Spacer(Modifier.height(12.dp))
                            Text("Автоснятие через $expire мин",fontSize=14.sp)
                            Slider(value=expire.toFloat(),onValueChange={expire=it.toInt()},
                                onValueChangeFinished={AlertState.setExpireMinutes(ctx,expire)},
                                valueRange=10f..180f,steps=33,
                                colors=SliderDefaults.colors(thumbColor=YandexRed,activeTrackColor=YandexRed))
                            Text("Тревога снимается, если за это время не было подтверждения",
                                fontSize=12.sp,color=TextSecondary)
                            Spacer(Modifier.height(12.dp))
                            YSecondary("Замерить историю канала",{
                                scope.launch {
                                    probe="Считаю…"
                                    probe=withContext(Dispatchers.IO) { HistoryProbe.analyze(10) }
                                }
                            },Modifier.fillMaxWidth())
                            if(probe.isNotBlank()) {
                                Spacer(Modifier.height(10.dp));Text(probe,fontSize=12.sp,color=TextSecondary)
                            }
                        }
                    }
                }
            }
            item {
                Text("Частоты",fontWeight=FontWeight.SemiBold,
                    modifier=Modifier.padding(start=4.dp,top=6.dp))
            }
            itemsIndexed(Stations.all) { i,st ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardColor)
                    .padding(horizontal=16.dp,vertical=14.dp),verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(NeutralSoft),
                        contentAlignment=Alignment.Center) {
                        Text("${i+1}",fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=TextSecondary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(st.region,Modifier.weight(1f),fontSize=15.sp,color=TextPrimary)
                    Text(st.freqMhz.toString().replace('.',','),fontSize=16.sp,
                        fontWeight=FontWeight.Bold,color=TextPrimary)
                    Spacer(Modifier.width(3.dp));Text("FM",fontSize=11.sp,color=TextSecondary)
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}
