(() => {
  const nav = document.getElementById("city-tabs");
  const select = document.getElementById("city");
  if (!nav || !select) return;

  let counts = {};

  function render() {
    nav.replaceChildren();

    [...select.options].forEach(option => {
      const button = document.createElement("button");
      button.type = "button";

      const count = option.value
        ? (counts[option.value] || 0)
        : Object.values(counts).reduce((a, b) => a + b, 0);

      button.textContent = option.textContent + " (" + count + ")";
      button.style.margin = "4px";
      button.disabled = option.value === select.value;

      button.addEventListener("click", () => {
        select.value = option.value;
        select.dispatchEvent(new Event("change", { bubbles: true }));
      });

      nav.appendChild(button);
    });
  }

  async function refresh() {
    try {
      const response = await fetch("/admin-api/news/pending?limit=100", {
        credentials: "same-origin"
      });
      if (!response.ok) return;

      const data = await response.json();
      counts = {};

      (data.items || []).forEach(item => {
        counts[item.city] = (counts[item.city] || 0) + 1;
      });

      render();
    } catch (error) {
      console.error("Ошибка счётчиков городов:", error);
    }
  }

  new MutationObserver(refresh).observe(select, { childList: true });
  select.addEventListener("change", render);

  render();
  refresh();
})();
