(() => {
  const list = document.getElementById("list");
  const panel = document.getElementById("counters");
  if (!list || !panel) return;

  function updateCounters() {
    const counts = {};
    const cards = list.querySelectorAll("article.item");

    cards.forEach(card => {
      const city = card.querySelector("p strong")?.textContent?.trim();
      if (city) counts[city] = (counts[city] || 0) + 1;
    });

    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    panel.textContent = "Показано: " + total + " | " +
      ["Горловка", "Донецк", "Макеевка"]
        .map(city => city + ": " + (counts[city] || 0))
        .join(" | ");
  }

  new MutationObserver(updateCounters).observe(list, {
    childList: true
  });

  updateCounters();
})();
