(() => {
  const $ = (s, root = document) => root.querySelector(s);

  async function api(url, method, body) {
    const response = await fetch(url, {
      method,
      credentials: "same-origin",
      headers: body ? { "Content-Type": "application/json" } : {},
      ...(body ? { body: JSON.stringify(body) } : {})
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || `HTTP ${response.status}`);
    return data;
  }

  function enhance(card) {
    if (card.dataset.moderationReady) return;

    const paragraphs = card.querySelectorAll("p");
    const idText = [...paragraphs].map(p => p.textContent).join(" ");
    const match = idText.match(/\bID\s*(\d+)\b/i);
    const title = $("h3", card);
    const city = $("strong", card);
    const summary = paragraphs[1];

    if (!match || !title || !city || !summary) return;

    const id = Number(match[1]);
    card.dataset.moderationReady = "1";

    const editor = document.createElement("div");
    editor.className = "moderation-editor";

    function field(labelText, name, value, multiline = false) {
      const label = document.createElement("label");
      label.textContent = labelText + " ";
      const input = document.createElement(multiline ? "textarea" : "input");
      input.dataset.field = name;
      input.value = value.trim();
      if (multiline) input.rows = 4;
      label.append(input);
      editor.append(label, document.createElement("br"));
    }

    field("Город", "city", city.textContent);
    field("Заголовок", "title", title.textContent);
    field("Текст новости", "summary", summary.textContent, true);

    const actions = document.createElement("div");
    actions.className = "moderation-actions";

    for (const [action, caption] of [
      ["save", "Сохранить правки"],
      ["confirm", "Подтвердить"],
      ["reject", "Отклонить"]
    ]) {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.action = action;
      button.dataset.id = String(id);
      button.textContent = caption;
      actions.append(button);
    }

    editor.append(actions);
    card.append(editor);
  }

  function scan() {
    document.querySelectorAll("#list .item").forEach(enhance);
  }

  const list = $("#list");
  if (!list) {
    console.error("Панель модерации: не найден элемент #list");
    return;
  }

  new MutationObserver(scan).observe(list, { childList: true, subtree: true });
  scan();

  list.addEventListener("click", async event => {
    const button = event.target.closest("button[data-action]");
    if (!button || !list.contains(button)) return;

    const id = Number(button.dataset.id);
    const card = button.closest(".item");
    const action = button.dataset.action;
    if (!Number.isInteger(id) || !card) return;

    const prompts = {
      save: `Сохранить правки новости ID ${id}?`,
      confirm: `Подтвердить новость ID ${id} и опубликовать её?`,
      reject: `Отклонить новость ID ${id}?`
    };
    if (!window.confirm(prompts[action])) return;

    let url = `/admin-api/news/${id}/${action}`;
    let method = "POST";
    let body;

    if (action === "save") {
      url = `/admin-api/news/${id}/edit`;
      method = "PATCH";
      body = {};
      card.querySelectorAll("[data-field]").forEach(input => {
        body[input.dataset.field] = input.value.trim();
      });

      if (!body.city || !body.title) {
        alert("Город и заголовок не должны быть пустыми.");
        return;
      }
      if (body.title.length > 300 || body.summary.length > 3000) {
        alert("Заголовок: до 300 символов. Текст: до 3000.");
        return;
      }
    } else if (!["confirm", "reject"].includes(action)) {
      return;
    }

    button.disabled = true;
    try {
      await api(url, method, body);
      alert(`Действие для новости ID ${id} выполнено.`);
      if ($("#reload")) $("#reload").click();
    } catch (error) {
      alert(`Не удалось выполнить действие: ${error.message}`);
      button.disabled = false;
    }
  });

  console.log("Панель модерации подключена.");
})();
