package com.example.dronesignal

import android.Manifest
import android.app.*
import android.content.*
import android.os.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.composed
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import kotlinx.coroutines.*
import java.net.*
import java.text.SimpleDateFormat
import java.time.OffsetDateTime
import java.util.*
import java.util.concurrent.TimeUnit

private val YandexRed = Color(0xFFFC3F1D)
private val YandexRedSoft = Color(0xFFFFE9E4)
private val BgColor = Color(0xFFF5F5F7)
private val CardColor = Color.White
private val TextPrimary = Color(0xFF1A1A1A)
private val TextSecondary = Color(0xFF8C8C8C)
private val DividerColor = Color(0xFFEDEDED)
private val GreenColor = Color(0xFF22A65A)
private val GreenSoft = Color(0xFFE7F6EE)
private val NeutralSoft = Color(0xFFF4F4F5)

object AlertState {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("alert_state",Context.MODE_PRIVATE)
    fun isActive(c: Context) = p(c).getBoolean("active",false)
    fun since(c: Context) = p(c).getLong("since",0L)
    fun source(c: Context) = p(c).getString("source","—") ?: "—"
    fun lastAlarm(c: Context) = p(c).getLong("last_alarm",0L)
    fun expireMinutes(c: Context) = p(c).getInt("expire_min",60)
    fun setExpireMinutes(c: Context,min: Int) { p(c).edit().putInt("expire_min",min.coerceIn(10,180)).apply() }
    fun start(c: Context,source: String) {
        val now=System.currentTimeMillis()
        p(c).edit().putBoolean("active",true).putLong("since",now).putLong("last_alarm",now).putString("source",source).apply()
    }
    fun renew(c: Context,source: String) { p(c).edit().putLong("last_alarm",System.currentTimeMillis()).putString("source",source).apply() }
    fun stop(c: Context,source: String) { p(c).edit().putBoolean("active",false).putString("source",source).apply() }
}
enum class PostKind { ALARM,CLEAR,IGNORE }
data class Classified(val kind: PostKind,val massive: Boolean,val region: String,val voiceText: String) {
    val relevant get() = region=="ДНР" || region=="ЛНР"
}
object AlarmClassifier {
    private fun norm(s: String) = s.lowercase(Locale("ru","RU")).replace('ё','е')
    private val alarmMarkers=listOf("бпла","беспилот","тревога","ракетная опасность","авиационная ракетная")
    private val massiveMarkers=listOf("массово","массовая атака","массированн")
    fun classify(raw: String): Classified {
        val clean=raw.replace(Regex("https?://\\S+"),"").replace(Regex("\\s+")," ").trim()
        val t=norm(clean)
        val kind=when {
            listOf("отбой","отмена тревоги","опасность отменена","все чисто").any { it in t } -> PostKind.CLEAR
            "по штормам" in t && "ранее объявленные регионы" in t -> PostKind.CLEAR
            alarmMarkers.any { it in t } -> PostKind.ALARM
            else -> PostKind.IGNORE
        }
        val massive=massiveMarkers.any { it in t }
        val region=when { "днр" in t -> "ДНР"; "лнр" in t -> "ЛНР"; else -> "" }
        val voice=when {
            kind==PostKind.CLEAR -> "Отбой опасности. "+clean.take(160)
            massive -> "Внимание! Массовая атака беспилотников. "+clean.take(160)
            else -> "Внимание! Опасность беспилотников. "+clean.take(160)
        }
        return Classified(kind,massive,region,voice)
    }
}
data class AlarmPost(val id: Long,val timeMs: Long,val text: String)
object TelegramAlarmSource {
    const val CHANNEL="lpr1_LDPR_alarm"
    fun fetchAll(): List<AlarmPost>? {
        val html=download("https://t.me/s/$CHANNEL") ?: return null
        return html.split("tgme_widget_message_wrap").drop(1).mapNotNull { parsePost(it) }.sortedBy { it.id }
    }
    internal fun parsePost(block: String): AlarmPost? {
        val id=Regex("data-post=\"[^\"]*?/(\\d+)\"").find(block)?.groupValues?.get(1)?.toLongOrNull() ?: return null
        val raw=Regex("tgme_widget_message_text[^>]*>(.*?)</div>",RegexOption.DOT_MATCHES_ALL).find(block)?.groupValues?.get(1) ?: ""
        val text=raw.replace(Regex("<br\\s*/?>"),"\n").replace(Regex("<[^>]+>")," ")
            .replace("&quot;","\"").replace("&#39;","'").replace("&amp;","&")
            .replace("&lt;","<").replace("&gt;",">").replace(Regex("\\s+")," ").trim()
        val time=Regex("datetime=\"([^\"]+)\"").find(block)?.groupValues?.get(1)
            ?.let { runCatching { OffsetDateTime.parse(it).toInstant().toEpochMilli() }.getOrNull() } ?: 0L
        return AlarmPost(id,time,text)
    }
    internal fun download(url: String): String? = runCatching {
        val conn=(URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout=10000;readTimeout=10000
            setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        }
        try { if(conn.responseCode !in 200..299) null else conn.inputStream.bufferedReader().use { it.readText() } }
        finally { conn.disconnect() }
    }.getOrNull()
}
object AlarmGuard {
    private const val MAX_POST_AGE_MS=10*60_000L
    fun poll(ctx: Context) {
        val now=System.currentTimeMillis()
        val posts=TelegramAlarmSource.fetchAll()
        if(posts==null) { expireIfSilent(ctx,now);return }
        val prefs=ctx.applicationContext.getSharedPreferences("guard",Context.MODE_PRIVATE)
        val lastId=prefs.getLong("last_id",0L)
        val fresh=posts.filter { it.id>lastId }
        if(fresh.isEmpty()) { expireIfSilent(ctx,now);return }
        var maxSeen=lastId
        for(post in fresh) {
            maxSeen=maxOf(maxSeen,post.id)
            if(post.timeMs<=0 || post.timeMs>now+60_000L || now-post.timeMs>MAX_POST_AGE_MS) continue
            handle(ctx,post.id,AlarmClassifier.classify(post.text))
        }
        prefs.edit().putLong("last_id",maxSeen).apply()
        expireIfSilent(ctx,now)
    }
    private fun handle(ctx: Context,id: Long,c: Classified) {
        val active=AlertState.isActive(ctx)
        when(c.kind) {
            PostKind.ALARM -> {
                if(!c.relevant && !active) return
                if(!active) { AlertState.start(ctx,"tg:$id");AlertVoiceService.start(ctx,c.voiceText) }
                else { AlertState.renew(ctx,"tg:$id");AlertVoiceService.update(ctx,c.voiceText) }
            }
            PostKind.CLEAR -> if(active && c.relevant) { AlertState.stop(ctx,"отбой tg:$id");AlertVoiceService.stop(ctx) }
            PostKind.IGNORE -> Unit
        }
    }
    private fun expireIfSilent(ctx: Context,now: Long) {
        if(!AlertState.isActive(ctx)) return
        val last=AlertState.lastAlarm(ctx)
        if(last>0 && now-last>AlertState.expireMinutes(ctx)*60_000L) {
            AlertState.stop(ctx,"таймаут");AlertVoiceService.stop(ctx)
        }
    }
}
class FastPollService: Service() {
    private val scope=CoroutineScope(Dispatchers.IO+SupervisorJob())
    override fun onCreate() {
        super.onCreate()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel("poll","Слежение",NotificationManager.IMPORTANCE_MIN))
        startForeground(2,NotificationCompat.Builder(this,"poll").setContentTitle("Слежение за каналом тревог")
            .setContentText("Ожидание сигнала…").setSmallIcon(android.R.drawable.ic_menu_compass)
            .setPriority(NotificationCompat.PRIORITY_MIN).setOngoing(true).build())
        scope.launch { while(isActive) { runCatching { AlarmGuard.poll(this@FastPollService) };delay(20_000L) } }
    }
    override fun onStartCommand(intent: Intent?,flags: Int,startId: Int)=START_STICKY
    override fun onBind(intent: Intent?): IBinder?=null
    override fun onDestroy() { scope.cancel();super.onDestroy() }
    companion object {
        fun start(ctx: Context) { ContextCompat.startForegroundService(ctx,Intent(ctx,FastPollService::class.java)) }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx,FastPollService::class.java)) }
    }
}
class AlertCheckWorker(ctx: Context,params: WorkerParameters): CoroutineWorker(ctx,params) {
    override suspend fun doWork(): Result {
        withContext(Dispatchers.IO) { runCatching { AlarmGuard.poll(applicationContext) } }
        return Result.success()
    }
    companion object {
        fun schedule(ctx: Context) {
            val req=PeriodicWorkRequestBuilder<AlertCheckWorker>(15,TimeUnit.MINUTES)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("alert_check",ExistingPeriodicWorkPolicy.KEEP,req)
        }
    }
}
object HistoryProbe {
    fun analyze(pages: Int=10): String {
        val all=mutableListOf<AlarmPost>()
        all+=TelegramAlarmSource.fetchAll().orEmpty()
        var before=all.minOfOrNull { it.id } ?: return "Нет постов канала"
        repeat(pages-1) {
            val page=TelegramAlarmSource.download("https://t.me/s/${TelegramAlarmSource.CHANNEL}?before=$before")
                ?.split("tgme_widget_message_wrap")?.drop(1)?.mapNotNull { TelegramAlarmSource.parsePost(it) } ?: return@repeat
            if(page.isEmpty()) return@repeat
            all+=page;before=page.minOf { it.id };Thread.sleep(1500)
        }
        val sorted=all.distinctBy { it.id }.sortedBy { it.id }
        if(sorted.size<4) return "Мало данных: ${sorted.size} постов"
        val durations=mutableListOf<Long>()
        var start: Long?=null
        for(p in sorted) {
            when(AlarmClassifier.classify(p.text).kind) {
                PostKind.ALARM -> if(start==null) start=p.timeMs
                PostKind.CLEAR -> { start?.let { if(p.timeMs>it) durations+=p.timeMs-it };start=null }
                PostKind.IGNORE -> Unit
            }
        }
        if(durations.isEmpty()) return "Эпизодов с отбоем нет (постов: ${sorted.size})"
        val s=durations.sorted()
        return buildString {
            appendLine("Постов: ${sorted.size}")
            appendLine("Эпизодов с отбоем: ${durations.size}")
            appendLine("Средняя: ${durations.average().toLong()/60_000} мин")
            appendLine("Медиана: ${s[s.size/2]/60_000} мин")
            appendLine("P90: ${s[(s.size*0.9).toInt().coerceAtMost(s.lastIndex)]/60_000} мин")
        }
    }
}
@Composable
fun YCard(modifier: Modifier=Modifier,content: @Composable ColumnScope.()->Unit) {
    Column(modifier.fillMaxWidth().shadow(4.dp,RoundedCornerShape(24.dp),spotColor=Color(0x14000000))
        .clip(RoundedCornerShape(24.dp)).background(CardColor).padding(20.dp),content=content)
}
@Composable
fun PulseDot(active: Boolean,color: Color) {
    if(!active) { Box(Modifier.size(10.dp).clip(CircleShape).background(color));return }
    val transition=rememberInfiniteTransition(label="pulse")
    val alpha by transition.animateFloat(initialValue=0.35f,targetValue=1f,
        animationSpec=infiniteRepeatable(tween(900,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="alpha")
    Box(Modifier.size(10.dp).clip(CircleShape).background(color.copy(alpha=alpha)))
}
@Composable
fun StatusHero(active: Boolean,title: String,subtitle: String) {
    val bg=if(active) YandexRed else GreenSoft
    val fg=if(active) Color.White else TextPrimary
    val sub=if(active) Color(0xFFFFD6CC) else TextSecondary
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
        .background(Brush.linearGradient(listOf(bg,if(active) Color(0xFFE8391A) else bg))).padding(24.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            PulseDot(active,if(active) Color.White else GreenColor);Spacer(Modifier.width(10.dp))
            Text(if(active) "ОПАСНОСТЬ" else "СЛЕЖЕНИЕ",fontSize=11.sp,fontWeight=FontWeight.Bold,
                letterSpacing=1.4.sp,color=if(active) Color(0xFFFFD6CC) else TextSecondary)
        }
        Spacer(Modifier.height(12.dp))
        Text(title,fontSize=26.sp,fontWeight=FontWeight.Bold,color=fg)
        Spacer(Modifier.height(6.dp));Text(subtitle,fontSize=14.sp,color=sub)
    }
}
@Composable
fun YPrimary(text: String,onClick: ()->Unit,modifier: Modifier=Modifier) {
    Button(onClick=onClick,modifier=modifier.height(52.dp),shape=RoundedCornerShape(14.dp),
        colors=ButtonDefaults.buttonColors(containerColor=TextPrimary,contentColor=Color.White),
        elevation=ButtonDefaults.buttonElevation(0.dp,0.dp,0.dp)) {
        Text(text,fontWeight=FontWeight.SemiBold,fontSize=15.sp)
    }
}
@Composable
fun YSecondary(text: String,onClick: ()->Unit,modifier: Modifier=Modifier) {
    Button(onClick=onClick,modifier=modifier.height(52.dp),shape=RoundedCornerShape(14.dp),
        colors=ButtonDefaults.buttonColors(containerColor=NeutralSoft,contentColor=TextPrimary),
        elevation=ButtonDefaults.buttonElevation(0.dp,0.dp,0.dp)) {
        Text(text,fontWeight=FontWeight.SemiBold,fontSize=15.sp)
    }
}
@Composable
fun YDanger(text: String,onClick: ()->Unit,modifier: Modifier=Modifier) {
    Button(onClick=onClick,modifier=modifier.height(52.dp),shape=RoundedCornerShape(14.dp),
        colors=ButtonDefaults.buttonColors(containerColor=YandexRed,contentColor=Color.White),
        elevation=ButtonDefaults.buttonElevation(0.dp,0.dp,0.dp)) {
        Text(text,fontWeight=FontWeight.SemiBold,fontSize=15.sp)
    }
}
fun Modifier.clickableNoRipple(onClick: ()->Unit): Modifier=composed {
    clickable(interactionSource=remember { MutableInteractionSource() },indication=null,onClick=onClick)
}
class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),1)
        AlertCheckWorker.schedule(this)
        setContent {
            MaterialTheme(colorScheme=lightColorScheme(primary=YandexRed,background=BgColor,surface=CardColor)) { NewAppScreen() }
        }
    }
}
